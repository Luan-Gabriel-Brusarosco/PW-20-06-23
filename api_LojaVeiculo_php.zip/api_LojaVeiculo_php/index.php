<?php
//header('Content-type: application/json');
require_once 'controller/index.php';