<?php
echo json_encode(
    ["arquivo"=>"montadora"]
);