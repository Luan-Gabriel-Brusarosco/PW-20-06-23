<?php
http_response_code($codigo_resposta);
echo json_encode($erro);