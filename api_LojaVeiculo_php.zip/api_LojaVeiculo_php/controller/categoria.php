<?php
echo json_encode(
    ["arquivo"=>"categoria"]
);