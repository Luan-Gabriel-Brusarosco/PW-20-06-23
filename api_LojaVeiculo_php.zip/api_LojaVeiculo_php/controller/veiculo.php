<?php
require_once 'model/Veiculo.php';
require_once 'view/Veiculo.php';
$veiculo = new Veiculo();
$viewVeiculo = new ViewVeiculo();

array_shift($url);
switch($method){    
    case "GET":{
        if(count($url)){
            if($url[0] == "modelo"){
                $veiculos = $veiculo->consultar(@$url[1]);
                $viewVeiculo->listarVeiculos($veiculos);
            }
            else if($url[0] == "id"){
                if($id = @$url[1]){
                    $veiculos = $veiculo->consultarPorId($id);
                echo json_encode(
                    [
                            "id"=>$id,
                            "modelo"=>$veiculo->modelo,
                            "ano de fabricacao"=>$veiculo->ano_fabricacao,
                            "ano modelo"=>$veiculo->ano_modelo,
                            "cor"=>$veiculo->cor,
                            "numero de portas"=>$veiculo->num_portas,
                            "foto"=>$veiculo->foto,
                            "categoria_id"=>$veiculo->categoria_id,
                            "montadora_id"=>$veiculo->montadora_id,
                            "tipo_cambio"=>$veiculo->tipo_cambio,
                            "tipo_direcao"=>$veiculo->tipo_direcao,
                            "data_cadastro"=>$veiculo->data_cadastro,
                            "data_alteracao"=>$veiculo->data_alteracao,
                            //"Info"=>"Ainda não foi definido",
                        ]   
                    );
                
                }
                else{
                    echo json_encode(["Info"=>"Nenhum carro detectado"]);
                    $veiculos = $veiculo->consultar();
                    $viewVeiculo->listarVeiculos($veiculos);
                }
            }
        }
        else{
            $veiculos = $veiculo->consultar();
            $viewVeiculo->listarVeiculos($veiculos);
        }
    }
    break;
    case "POST":{
        echo json_encode(["method"=>"POST"]);
    }
    break;
    case "PUT":{
        echo json_encode(["method"=>"PUT"]);
    }
    break;
    case "DELETE":{
        echo json_encode(["method"=>"DELETE"]);
    }
    break;
    default:{
        echo json_encode(["method"=>"ERRO"]);
    }
    break;
}